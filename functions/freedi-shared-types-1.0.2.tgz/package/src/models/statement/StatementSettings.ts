import {
	object,
	optional,
	nullable,
	array,
	string,
	boolean,
	enum_,
	picklist,
	InferOutput,
	number,
} from 'valibot';
import { DeliberationType, SortType, ThemeStyle } from '../TypeEnums';
import {
	ClassBallotSchema,
	ClassVoteDisplaySchema,
	RoundPhaseSchema,
} from '../classroom/classroomModel';

/**
 * Join form — admin-defined contact form shown the first time a user joins
 * any option under a question. Submission is stored once per user per
 * owning question, either in Firestore or appended to a Google Sheet.
 */
export const JoinFormFieldTypeSchema = picklist(['text', 'phone', 'email']);
export type JoinFormFieldType = InferOutput<typeof JoinFormFieldTypeSchema>;

export const JoinFormFieldSchema = object({
	id: string(),       // stable slug used as the form key
	label: string(),    // display label (admin-provided, admin handles translation)
	type: JoinFormFieldTypeSchema,
	required: boolean(),
});
export type JoinFormField = InferOutput<typeof JoinFormFieldSchema>;

export const JoinFormDestinationSchema = picklist(['firestore', 'sheets']);
export type JoinFormDestination = InferOutput<typeof JoinFormDestinationSchema>;

export const JoinFormConfigSchema = object({
	enabled: boolean(),
	fields: array(JoinFormFieldSchema),
	destination: JoinFormDestinationSchema,
	sheetUrl: optional(string()),
	// Language the admin used when saving the form (e.g. 'he', 'en'). The join
	// app renders the modal chrome (title, buttons) in this language so they
	// match the stored field labels regardless of the visitor's browser lang.
	formLanguage: optional(string()),
});
export type JoinFormConfig = InferOutput<typeof JoinFormConfigSchema>;

/**
 * Conditional-joining resolution — lets admins run a one-time "Resolve" step
 * that filters out options below minJoinMembers. Until resolved, every join
 * is a conditional intent ("count me in if this reaches N"). After resolve,
 * surviving options become firm memberships and users with too many intents
 * are prompted to prune to `maxCommitmentsPerUser`.
 */
export const JoinResolutionPhaseSchema = picklist(['intent', 'resolved']);
export type JoinResolutionPhase = InferOutput<typeof JoinResolutionPhaseSchema>;

export const JoinResolutionConfigSchema = object({
	enabled: boolean(),
	phase: JoinResolutionPhaseSchema,
	maxCommitmentsPerUser: number(),
	resolvedAt: optional(number()),
	resolvedBy: optional(string()),
	activatedCount: optional(number()),
	failedCount: optional(number()),
	orphanedCount: optional(number()),
	pruningCount: optional(number()),
});
export type JoinResolutionConfig = InferOutput<typeof JoinResolutionConfigSchema>;

/**
 * Question status — facilitator-controlled lifecycle gate.
 *  - 'live'   : normal operation (default when unset).
 *  - 'frozen' : the question is visible but no one can join, un-join, or
 *               submit/change evaluations. Read-only snapshot of the room.
 *  - 'closed' : participants see only a "This question is closed" screen
 *               instead of the question content.
 *
 * Used by the Join app's FacilitatorPanel. Admins can flip between states
 * at any time; closing then reopening preserves all existing data.
 */
export const QuestionStatusSchema = picklist(['live', 'frozen', 'closed']);
export type QuestionStatus = InferOutput<typeof QuestionStatusSchema>;

/**
 * Activation threshold — minimum number of activists and organizers
 * required before an option is considered "activated". When enabled,
 * users see how many more people are needed.
 *
 * `maxJoinsPerUser` (optional) caps how many sibling options a single
 * participant may join as activist under this question. When the user
 * tries to join past the cap, the join app prompts them to swap out one
 * existing membership for the new one. 0 / undefined disables the cap.
 */
export const ActivationThresholdSchema = object({
	enabled: boolean(),
	minActivists: optional(number()),
	minOrganizers: optional(number()),
	maxJoinsPerUser: optional(number()),
});
export type ActivationThreshold = InferOutput<typeof ActivationThresholdSchema>;

/**
 * Condensation / "Grouped suggestions" — creates a new sibling statement
 * (with `isCluster: true` and `integratedOptions: [...sourceIds]`) that
 * represents a group of semantically similar originals. Originals are NOT
 * reparented, hidden, or modified — they remain live in the database.
 * Whether voters see them in the UI is controlled per-surface via `visibility`.
 *
 * Evaluations aggregate upward from originals into the cluster via the
 * existing `fn_clusterAggregation` pipeline (deduped per evaluator).
 */
export const CondensationLevelSchema = picklist(['loose', 'balanced', 'tight']);
export type CondensationLevel = InferOutput<typeof CondensationLevelSchema>;

export const CondensationSurfaceVisibilitySchema = picklist(['both', 'clusters-only']);
export type CondensationSurfaceVisibility = InferOutput<typeof CondensationSurfaceVisibilitySchema>;

export const CondensationVisibilitySchema = object({
	main: CondensationSurfaceVisibilitySchema,
	massConsensus: CondensationSurfaceVisibilitySchema,
	join: CondensationSurfaceVisibilitySchema,
});
export type CondensationVisibility = InferOutput<typeof CondensationVisibilitySchema>;

/**
 * The three independent "View layers" toggles on the Solutions tab. Composing
 * them yields the named states (All / Raw only / Synth+Raw / Clusters / Synth
 * only). Stored as the admin default; per-user overrides live in localStorage.
 */
export const ViewLayersSchema = object({
	raw: boolean(), // show raw participant ideas
	synth: boolean(), // show AI-synthesized proposals
	cluster: boolean(), // group into topic-cluster cards (synth + raw nested)
});
export type ViewLayers = InferOutput<typeof ViewLayersSchema>;

export const CondensationConfigSchema = object({
	enabled: boolean(),
	level: CondensationLevelSchema, // maps to similarity threshold via CONDENSATION_THRESHOLDS
	autoApply: boolean(), // false = creator approves groups via preview before they publish
	allowCreatorOverrides: boolean(),
	minGroupSize: number(), // minimum members required to form a cluster (default 2)
	visibility: CondensationVisibilitySchema, // per-surface display mode
	allowDrillToOriginals: boolean(), // when visibility is clusters-only, can voters drill to see originals
	// Admin-set default for the Solutions "View layers" toggles (Raw / Synth /
	// Cluster). Each user can override locally (localStorage); this is the
	// fallback everyone lands on. Optional → falls back to all-on ("All").
	viewLayers: optional(ViewLayersSchema),
	// Eligibility filters: only options that meet BOTH thresholds are considered
	// for automatic clustering. Creator overrides (drag-drop) bypass these.
	// Undefined or 0 disables the filter.
	minAverageForClustering: optional(number()), // e.g. 0.7 means only cluster options with avg eval >= 0.7
	minEvaluatorsForClustering: optional(number()), // e.g. 3 means only cluster options with >=3 evaluators
});
export type CondensationConfig = InferOutput<typeof CondensationConfigSchema>;

/**
 * Idea Synthesis — bulk near-duplicate detection across all options under a
 * question. Distinct from topic clustering (broad themes) and condensation
 * (UMAP/DBSCAN re-grouping). Produces verified-same merge groups via
 * embedding ANN + LLM-as-judge (four-way verdict: same/related/different/
 * opposite). Resulting merged statements use the existing isCluster=true +
 * integratedOptions[] data model so render and aggregation paths are shared.
 *
 * See docs/clusters and synthesis/clustering-and-synthesis-paper.md §5 for the full method.
 *
 * All fields optional — synthesis is admin-triggered and does not run unless
 * settings are present and `enabled` is true.
 */
export const SynthesisConfigSchema = object({
	enabled: optional(boolean()), // master switch for the synthesis admin button
	defaultThreshold: optional(number()), // cosine candidate threshold, default 0.90
	// Eligibility filters applied BEFORE any embedding op. Undefined disables.
	minAverageForSynthesis: optional(number()),
	minConsensusForSynthesis: optional(number()), // new filter requested for synthesis flow
	minEvaluatorsForSynthesis: optional(number()),
});
export type SynthesisConfig = InferOutput<typeof SynthesisConfigSchema>;

/**
 * Cluster-map display settings — admin-controlled rendering of the radial
 * cluster board (ClusterBoard). Persisted on the question so every viewer sees
 * the same map. All fields optional → the board falls back to its built-in
 * defaults (see ClusterBoard MAP_FONT_* / MAP_SYNTH_VISIBILITY_DEFAULT).
 */
/**
 * @deprecated Replaced by `MapDetailLevel` (`defaultDetail`). Still read for
 * migration: 'clusters-only' → 'themes', 'all' → 'ideas', 'originals-only' → 'everything'.
 */
export const MapSynthVisibilitySchema = picklist([
	'all', // clusters/synth AND ungrouped originals (default)
	'clusters-only', // only clustered/synth groups; hide the ungrouped block
	'originals-only', // flatten everything to originals; hide cluster grouping
]);
export type MapSynthVisibility = InferOutput<typeof MapSynthVisibilitySchema>;

/**
 * How deep a map viewer looks into the topic → synth → original hierarchy.
 * Acts as a MAXIMUM depth; individual nodes can be expanded further by the viewer.
 * - `themes`     — topic clusters only (a table of contents).
 * - `ideas`      — topics opened to their merged ideas (synths) + ungrouped originals. Default.
 * - `everything` — synths opened to the original statements they were merged from.
 */
export const MapDetailLevelSchema = picklist(['themes', 'ideas', 'everything']);
export type MapDetailLevel = InferOutput<typeof MapDetailLevelSchema>;

// Which score the map filter keys off of. 'none' = no filtering (default).
export const MapFilterMetricSchema = picklist([
	'none', // show every response (default)
	'consensus', // filter by statement.consensus (Cₚ)
	'average', // filter by statement.evaluation.averageEvaluation
]);
export type MapFilterMetric = InferOutput<typeof MapFilterMetricSchema>;

export const MapSettingsSchema = object({
	cardFontRem: optional(number()), // sticky-note (card) text size, rem
	clusterFontRem: optional(number()), // cluster pill + hub title size, rem
	synthVisibility: optional(MapSynthVisibilitySchema), // @deprecated — see defaultDetail
	defaultDetail: optional(MapDetailLevelSchema), // starting depth for participants (default 'ideas')
	allowViewerExpand: optional(boolean()), // participants may expand nodes past the default depth (default true)
	showProvenance: optional(boolean()), // show "made from N responses" on clusters
	filterMetric: optional(MapFilterMetricSchema), // which score to filter by (default 'none')
	minConsensus: optional(number()), // threshold when filterMetric === 'consensus', range [-1,1]
	minAverageEvaluation: optional(number()), // threshold when filterMetric === 'average', range [-1,1]
	allowViewerFilter: optional(boolean()), // admin lets non-admin viewers adjust the filter
});
export type MapSettings = InferOutput<typeof MapSettingsSchema>;

export enum evaluationType {
	likeDislike = 'like-dislike',
	range = 'range',
	singleLike = 'single-like',
	communityVoice = 'community-voice',
}

/**
 * How participants evaluate options — cross-app source of truth.
 *
 * - 'agree-disagree' (default): the classic signed scale in [-1, +1]
 *   (strongly-disagree … strongly-agree). Sign encodes polarity, magnitude
 *   encodes intensity; consensus math relies on this.
 * - 'reactions': a positive-only 0→1 emoji-reaction scale (😐 0 · 🙂 0.25 ·
 *   😊 0.5 · 👍 0.75 · ❤️ 1). No "disagree" — expresses degrees of liking.
 *
 * The concrete scale (values, emoji, labels, throw direction) is defined once
 * in `evaluationScale.ts` via `getEvaluationScale(mode)` so every app renders
 * and validates the same thing. Undefined = 'agree-disagree'.
 */
export const RatingModeSchema = picklist(['agree-disagree', 'reactions']);
export type RatingMode = InferOutput<typeof RatingModeSchema>;

/**
 * Which options the voting view lists. 'all' (or undefined) shows every
 * option; 'positivelyEvaluated' shows only the options the group scored
 * positively in the card-stack evaluation (consensus > 0).
 */
export const VotingOptionsSourceSchema = picklist(['all', 'positivelyEvaluated']);
export type VotingOptionsSource = InferOutput<typeof VotingOptionsSourceSchema>;


/**
 * join-class (classroom): the step keys of a lesson. A lesson stores its own
 * ordered list in `LessonPlan.steps` and `stepIndex` points into THAT list:
 * lessons created before 'allProposals' existed keep their 8 stored steps, new
 * ones get 9. Readers index `steps[stepIndex]`, never a fixed list.
 * 'allProposals' (IA 19) sits between 'proposals' and 'vote'.
 */
export const LessonStepKeySchema = picklist([
	'waiting',
	'opening',
	'side',
	'tables',
	'tableTalk',
	'proposals',
	'allProposals',
	'vote',
	'summary',
]);
export type LessonStepKey = InferOutput<typeof LessonStepKeySchema>;

/** join-class lesson status. Absent = 'live' (lessons created before status existed). */
export const LessonStatusSchema = picklist(['live', 'paused', 'open', 'ended']);
export type LessonStatus = InferOutput<typeof LessonStatusSchema>;

export const LessonPlanSchema = object({
	steps: array(LessonStepKeySchema),
	stepIndex: number(),
	/** Added optionally: a strict parse of an older lesson must keep working. All moments in ms. */
	status: optional(LessonStatusSchema),
	statusAt: optional(number()),
	/** Set while paused, cleared on resume (after the table timers are shifted). */
	pausedAt: optional(number()),
	/** The last time the lesson was ended or kept open. */
	endedAt: optional(number()),
	/** Opening step: id of the introduction video the projector shows. Absent or null = the text. Cleared on every step change. */
	projectorVideoId: optional(nullable(string())),
});
export type LessonPlan = InferOutput<typeof LessonPlanSchema>;

/** join-class: a sub-question is either a guiding question or the one challenge. */
export const ClassRoleSchema = picklist(['guiding', 'challenge']);
export type ClassRole = InferOutput<typeof ClassRoleSchema>;

export const StatementSettingsSchema = object({
	subScreens: optional(array(string())),
	enableAddEvaluationOption: optional(boolean()),
	// Join app: when true, a participant composing a suggestion may broadcast
	// their draft letter-by-letter (RTDB liveDrafts/{questionId}/{uid}) to
	// everyone viewing this sub-question. Default (undefined/false) = off.
	enableLiveDraftBroadcast: optional(boolean()),
	enableEvaluation: optional(boolean()), // if false, the user cannot evaluate or vote
	enableAddNewSubQuestionsButton: optional(boolean()),
	defaultLookForSimilarities: optional(boolean()),
	isSubmitMode: optional(boolean()), // should a submit button appear in the bottom. it transfer to a thank you page when clicked. It is just used for the user to feel that he finished evaluating.
	enableAddVotingOption: optional(boolean()),
	/** @deprecated Auto-derived from evaluationType. Do not set directly — use evaluationType instead. */
	enhancedEvaluation: optional(boolean()),
	evaluationType: optional(enum_(evaluationType)),
	joiningEnabled: optional(boolean()),
	singleJoinOnly: optional(boolean()), // If true, user can only join ONE option under this parent
	dualRoleJoin: optional(boolean()), // Join app: when true, options expose two buttons (activist + organizer). Default (undefined/false) = single "Join" button.
	minJoinMembers: optional(number()), // Minimum members per option (for visual indicator)
	maxJoinMembers: optional(number()), // Maximum members per option (for visual indicator + split trigger)
	showEvaluation: optional(boolean()),
	// Join app: when undefined or true, every option card renders the join
	// row (Activist / Organizer buttons, or single Join when dualRoleJoin
	// is explicitly false). Set false to hide all join buttons — admins use
	// this for a pure-evaluation round. Default ON ("opt-out") so a fresh
	// question keeps the join experience the participant expects.
	showJoining: optional(boolean()),
	// Join app: when true, every option card renders the results strip
	// (consensus / average / evaluators) regardless of whether the 5-face
	// evaluation row itself is being shown. Independent from showEvaluation
	// so admins can reveal results at a chosen moment in a facilitated session
	// without changing the participant evaluation mode.
	showResults: optional(boolean()),
	inVotingGetOnlyResults: optional(boolean()),
	// Voting view only: undefined / 'all' = list every option;
	// 'positivelyEvaluated' = only options with positive card-stack consensus.
	votingOptionsSource: optional(VotingOptionsSourceSchema),
	enableSimilaritiesSearch: optional(boolean()),
	enableNavigationalElements: optional(boolean()),
	show: optional(boolean()),
	deliberationType: optional(enum_(DeliberationType)),
	hasChat: optional(boolean()),
	hasChildren: optional(boolean()),
	numberOfOptionsPerUser: optional(number()),
	// Minimum number of words a participant's response must contain to be
	// accepted. Undefined or <= 0 means "no minimum" (the default — nothing is
	// enforced). Admins can set it from the MC per-question editor or the
	// cluster/sticky-note map control panel. Enforced server-side on submit.
	minResponseWords: optional(number()),
	// How participants evaluate options under this statement. Cross-app: read
	// by every evaluation surface (MC swipe/classic, main-app faces, etc.) via
	// getEvaluationScale(ratingMode). Undefined = 'agree-disagree' (default).
	ratingMode: optional(RatingModeSchema),
	// How many steps the agree-disagree scale offers: 3 = -1 · 0 · +1, anything
	// else (undefined / 5) = the classic five. A plain number rather than a
	// third RatingMode so surfaces built before it existed still parse the
	// Statement and fall back to five steps. Ignored in 'reactions' mode. Read
	// it through resolveEvaluationScaleKey(statementSettings).
	ratingSteps: optional(number()),
	enableAIImprovement: optional(boolean()),
	popperianDiscussionEnabled: optional(boolean()),
	popperianPreCheckEnabled: optional(boolean()),
	enableMultiSuggestionDetection: optional(boolean()),
	enableAutoMerge: optional(boolean()), // if true (default), similar proposals will be automatically merged; if false, users choose
	// Automatic AI handling of a participant's submission, mirrored here from
	// the MC survey settings (see cascadeAutoAiHandling) so a question opened
	// outside any survey — /q/<statementId> — behaves the way its admin set it.
	// autoSplit: several answers in one submission are added separately instead
	// of asking the participant; autoMerge: a submission that repeats an
	// existing suggestion folds into it and +1s it. Undefined = off.
	autoSplitMultiSuggestions: optional(boolean()),
	autoMergeSimilar: optional(boolean()),
	similarityThreshold: optional(number()), // 0-1, default 0.85 - threshold for finding similar options
	excludedInheritedDemographicIds: optional(array(string())), // IDs of inherited demographic questions to exclude for this statement
	enableChatPanel: optional(boolean()), // if false, the chat side panel is hidden (default: true)
	enableSubQuestionsMap: optional(boolean()), // if false, the sub-questions map side panel is hidden (default: true)
	defaultView: optional(string()), // 'chat' | 'options' | 'questions' - default view for the segmented control
	defaultSortType: optional(enum_(SortType)), // default sort for options/suggestions (e.g., 'accepted' for consensus sort)
	enableTreeView: optional(boolean()), // if true, show threaded tree discussion instead of flat chat
	enableResearchLogging: optional(boolean()), // if true, research actions are logged for this statement and all sub-statements
	joinForm: optional(JoinFormConfigSchema), // admin-defined join form shown on first join under this question
	joinResolution: optional(JoinResolutionConfigSchema), // conditional-joining lifecycle (intent → resolved)
	enableHybridClustering: optional(boolean()), // if true, hybrid text+rating clustering runs for this question and sub-questions
	activationThreshold: optional(ActivationThresholdSchema), // min activists/organizers to activate an option
	condensation: optional(CondensationConfigSchema), // grouped suggestions feature — see CondensationConfigSchema
	synthesis: optional(SynthesisConfigSchema), // bulk idea synthesis — see SynthesisConfigSchema
	map: optional(MapSettingsSchema), // cluster-map display controls — see MapSettingsSchema
	// Join app: when true, a QR code section is rendered that any participant
	// can use to share this statement's URL with someone nearby (peer-to-peer
	// invite). Honoured on both the main statement (MainHub → hub URL) and on a
	// sub-question (Solutions → that question's URL); the two are independent
	// flags on independent docs. Admin-controlled via the FacilitatorPanel.
	showQR: optional(boolean()),
	// Join app: seed used when `defaultSortType === SortType.random` so every
	// participant computes the same shuffle locally. Admin re-randomizes by
	// pressing the Random sort button again, which writes a fresh seed.
	randomSortSeed: optional(number()),
	// Admin hand-placed ordering of this question's options, by statementId.
	// When non-empty it wins over `defaultSortType`; `null` clears it and hands
	// the list back to the sort. Written by the join app's FacilitatorPanel and
	// by the main app's Top Answers panel — both read by both.
	manualOptionOrder: optional(nullable(array(string()))),
	// Same, for the join app's separate organizer-suggestions list.
	manualOrganizerOrder: optional(nullable(array(string()))),
	// Join app: visual style family. Each style has its own light + dark
	// palette tuned for legibility (system prefers-color-scheme still drives
	// light vs dark). Default = serious (current earth-tone palette).
	themeStyle: optional(enum_(ThemeStyle)),
	// Join app: facilitator-controlled lifecycle gate. Default (undefined) is
	// treated as 'live'. 'frozen' blocks joining/un-joining/evaluation while
	// still showing the question; 'closed' replaces the question with a
	// "This question is closed" screen.
	questionStatus: optional(QuestionStatusSchema),
	// Join app: when true, participants (not just admins) may navigate the hub
	// on their own — sub-question cards become clickable and a Back button
	// appears inside each question. Default (undefined/false) keeps the
	// facilitator-led flow where `powerFollowMe` is the only way to move.
	// Hub-scoped — only honoured on the main (top-parent) statement.
	allowParticipantNavigation: optional(boolean()),
	// join-class: the lesson's step plan + current step. Main (workspace) statement only.
	lessonPlan: optional(LessonPlanSchema),
	// join-class: 6-digit join code of the workspace (classCodes/{code}). Main statement only.
	classCode: optional(string()),
	// join-class: role of a sub-question in the lesson (guiding | challenge).
	classRole: optional(ClassRoleSchema),
	// join-class: one-line hint shown under a sub-question.
	hint: optional(string()),
	// join-class: frozen vote shortlist, on the challenge question.
	ballot: optional(ClassBallotSchema),
	// join-class: the teacher's switches for the students' vote screen, on the challenge question.
	voteDisplay: optional(ClassVoteDisplaySchema),
	// join-class: plenum phase on the challenge question.
	roundPhase: optional(RoundPhaseSchema),
	// join-class: https link of the dilemma video shown on the opening screen. Main statement only.
	// @deprecated Superseded by `introVideos`; readers fall back to it until no lesson carries it.
	videoUrl: optional(string()),
	// join-class: the lesson introduction's ordered videos (0-5). Main statement only.
	introVideos: optional(array(object({ id: string(), title: string(), url: string() }))),
	// join-class: character names of side A and side B. Main statement only.
	sideNames: optional(object({ a: string(), b: string() })),
});


export type StatementSettings = InferOutput<typeof StatementSettingsSchema>;
