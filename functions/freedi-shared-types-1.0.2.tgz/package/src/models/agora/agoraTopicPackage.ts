import {
	object,
	string,
	number,
	boolean,
	optional,
	array,
	tupleWithRest,
	record,
	enum_,
	picklist,
	InferOutput,
} from 'valibot';
import { stagePlanPreset } from './stagePlan';
import type { AgoraStagePlanItem } from './stagePlan';
import { AgoraSceneKind, AgoraTopicStatus } from './agoraEnums';
import {
	AgoraLibraryCardSchema,
	AgoraLibraryStatsSchema,
	AgoraLibraryVisibilitySchema,
} from './agoraLibrary';

/** A value held by a historical character — also the AI grading answer key */
export const AgoraValueSchema = object({
	valueId: string(),
	label: string(),
	description: string(),
});

export type AgoraValue = InferOutput<typeof AgoraValueSchema>;

export const AgoraCharacterSchema = object({
	characterId: string(),
	name: string(),
	/** e.g. "Royalist noble", "Jacobin lawyer" */
	role: string(),
	portraitUrl: optional(string()),
	/** The character's spoken arguments, in presentation order */
	arguments: array(string()),
	/**
	 * The human needs beneath the positions — the character's answer to
	 * "what do you actually need?", shown after the arguments to build
	 * empathy. Optional for packages authored before the needs stage.
	 */
	needs: optional(array(string())),
	/** The values underlying the arguments — used as the grading answer key */
	values: array(AgoraValueSchema),
	/**
	 * An Odyssey Elder persona (AI character inspired by a historical leader)
	 * appended to a civic package. When any character carries this flag, the
	 * ask-the-characters panel shows only the elders — the two stance "voices"
	 * that wear the schema for the positioning scale stay off the panel.
	 */
	isElder: optional(boolean()),
});

export type AgoraCharacter = InferOutput<typeof AgoraCharacterSchema>;

export const AgoraDialogueLineSchema = object({
	speaker: string(),
	line: string(),
});

export type AgoraDialogueLine = InferOutput<typeof AgoraDialogueLineSchema>;

/**
 * One YouTube video a teacher pasted into a scene. Only the id is stored —
 * never the raw link or any HTML — and clients build the youtube-nocookie
 * embed URL from it.
 */
export const AgoraYoutubeVideoSchema = object({
	/** The 11-character YouTube video id */
	videoId: string(),
	/** A teacher-written label; clients fall back to "Video N" when absent */
	title: optional(string()),
	/** Where playback begins, from a `&t=` / `?t=` in the pasted link */
	startSeconds: optional(number()),
});

export type AgoraYoutubeVideo = InferOutput<typeof AgoraYoutubeVideoSchema>;

/**
 * One narrative scene. If videoUrl is missing, clients render the
 * dialogue/text fallback over the scene images.
 */
export const AgoraSceneSchema = object({
	sceneId: string(),
	kind: enum_(AgoraSceneKind),
	title: string(),
	text: string(),
	videoUrl: optional(string()),
	/**
	 * Any number of YouTube videos, in the teacher's order. Independent of the
	 * uploaded `videoUrl`, which keeps working as before.
	 */
	youtubeVideos: optional(array(AgoraYoutubeVideoSchema)),
	imageUrls: array(string()),
	dialogue: array(AgoraDialogueLineSchema),
});

export type AgoraScene = InferOutput<typeof AgoraSceneSchema>;

export const AgoraHealthMetricDefSchema = object({
	metricId: string(),
	label: string(),
	description: string(),
	min: number(),
	max: number(),
	baseline: number(),
	/** false for metrics where a drop is good (e.g. bread price); default true */
	higherIsBetter: optional(boolean()),
});

export type AgoraHealthMetricDef = InferOutput<typeof AgoraHealthMetricDefSchema>;

export const AgoraRubricCriterionSchema = object({
	criterionId: string(),
	label: string(),
	description: string(),
	/** Relative weight, all criteria of a rubric sum to 1 */
	weight: number(),
});

export type AgoraRubricCriterion = InferOutput<typeof AgoraRubricCriterionSchema>;

export const AgoraPlausibilityRubricSchema = object({
	criteria: array(AgoraRubricCriterionSchema),
});

export type AgoraPlausibilityRubric = InferOutput<typeof AgoraPlausibilityRubricSchema>;

export const AgoraPositioningScaleSchema = object({
	leftLabel: string(),
	rightLabel: string(),
	leftCharacterId: string(),
	rightCharacterId: string(),
});

export type AgoraPositioningScale = InferOutput<typeof AgoraPositioningScaleSchema>;

/** AI-generated or teacher-replaced era artwork for the 2.5D map */
export const AgoraArtworkSchema = object({
	mapBackdropUrl: optional(string()),
	/** location key (e.g. 'portal', 'palace', 'assembly', 'square') → image URL */
	locationVignetteUrls: optional(record(string(), string())),
	/** The style-locked prompt used to generate this set, kept for consistent regeneration */
	stylePrompt: optional(string()),
});

export type AgoraArtwork = InferOutput<typeof AgoraArtworkSchema>;

export const AgoraValueAnswerKeySchema = object({
	characterId: string(),
	expectedValues: array(AgoraValueSchema),
});

export type AgoraValueAnswerKey = InferOutput<typeof AgoraValueAnswerKeySchema>;

/**
 * How a package came to be. A `scenario` is the authored time-tunnel package
 * (characters, scenes, the era's health metrics). A `quick` package is the
 * minimal shell `agoraCreateSession` writes for a game the admin started by
 * typing a main question: two placeholder characters to satisfy the tuple,
 * no scenes, nothing to simulate. Absent means `scenario`.
 */
export const AgoraTopicKindSchema = picklist(['scenario', 'quick']);

export type AgoraTopicKind = InferOutput<typeof AgoraTopicKindSchema>;

export const AgoraTopicPackageSchema = object({
	topicPackageId: string(),
	creatorId: string(),
	kind: optional(AgoraTopicKindSchema),
	/** The teacher's original topic prompt, e.g. "המהפכה הצרפתית" */
	topic: string(),
	/** Original teacher intent, retained separately from the editable AI draft. */
	authoringBrief: optional(object({ statement: string(), description: string() })),
	/** BCP-47 language code the package content is written in */
	language: string(),
	status: enum_(AgoraTopicStatus),
	title: string(),
	/** The "save the era" mission framing shown to students */
	framingText: string(),
	/**
	 * The first two are the era's two sides (the positioning scale's voices);
	 * any further entries are appended personas — today the Odyssey elders,
	 * flagged `isElder`.
	 */
	characters: tupleWithRest([AgoraCharacterSchema, AgoraCharacterSchema], AgoraCharacterSchema),
	positioningScale: AgoraPositioningScaleSchema,
	challengeQuestion: string(),
	valueAnswerKey: array(AgoraValueAnswerKeySchema),
	plausibilityRubric: AgoraPlausibilityRubricSchema,
	healthMetrics: array(AgoraHealthMetricDefSchema),
	scenes: array(AgoraSceneSchema),
	artwork: optional(AgoraArtworkSchema),
	/**
	 * The teachers' library. All optional, all server-written (rules refuse a
	 * client write to `stats` and `library`): absent `visibility` means private.
	 * A public scenario is listed, rated and copyable by approved teachers only.
	 */
	visibility: optional(AgoraLibraryVisibilitySchema),
	library: optional(AgoraLibraryCardSchema),
	stats: optional(AgoraLibraryStatsSchema),
	/** On a copy taken from the library: the original scenario's id... */
	sourceScenarioId: optional(string()),
	/** ...its title and author as they were, so the credit survives the original going private... */
	sourceTitle: optional(string()),
	sourceAuthorName: optional(string()),
	/** ...and the original's `lastUpdate` when this copy was taken ("a new version is available" compares to it) */
	sourceVersion: optional(number()),
	createdAt: number(),
	lastUpdate: number(),
});

export type AgoraTopicPackage = InferOutput<typeof AgoraTopicPackageSchema>;

/** Every scenario, question-led or not, starts from the WizCol plan (no vision round). */
export function topicStagePlan(): AgoraStagePlanItem[] {
	return stagePlanPreset('scenarioWizcol');
}
