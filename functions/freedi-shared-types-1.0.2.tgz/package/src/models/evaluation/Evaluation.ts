import { object, string, number, boolean, optional, InferOutput, enum_, array } from 'valibot';
import { UserSchema } from '../user/User';

export const EvaluationSchema = object({
	parentId: string(),
	evaluationId: string(),
	statementId: string(),
	evaluatorId: string(),
	updatedAt: number(),
	evaluation: number(),
	evaluator: optional(UserSchema),
	/** Whether this evaluation was collected during test/pilot mode */
	isTestData: optional(boolean()),
	/** Timestamp when this data was retroactively marked as test data (if applicable) */
	markedAsTestAt: optional(number()),
	/**
	 * The statementId under which this evaluator's demographic answers are
	 * stored (i.e. getStatementIdForSurvey(survey)). Set when the evaluation
	 * was submitted inside a survey session so the polarization index can
	 * look up the evaluator's demographics directly instead of relying on
	 * an ancestor walk. Omitted for evaluations made outside any survey.
	 */
	demographicAnchorId: optional(string()),
	/**
	 * Set when the evaluation was made inside an agora classroom session.
	 * Guards the agora bridging-score trigger — evaluations without it never
	 * touch the agora pipeline.
	 */
	agoraSessionId: optional(string()),
});

export type Evaluation = InferOutput<typeof EvaluationSchema>;

export const EvaluatorSchema = object({
	evaluatorId: optional(string()),
	statementId: optional(string()),
	evaluated: optional(boolean()),
	suggested: optional(boolean()),
	firstEvaluation: optional(boolean()),
	secondEvaluation: optional(boolean()),
	voted: optional(boolean()),
});

export type Evaluator = InferOutput<typeof EvaluatorSchema>;

export enum SelectionFunction {
	random = 'random',
	top = 'top',
	vote = 'vote',
}

export const StatementEvaluationSchema = object({
	sumEvaluations: number(), //sum of all evaluations
	asParentTotalEvaluators: optional(number()), //sum of all evaluators as a parent
	agreement: number(),
	numberOfEvaluators: number(),
	sumPro: optional(number()), //sum of all pro evaluations
	sumCon: optional(number()), //sum of all con evaluations
	numberOfProEvaluators: optional(number()), //count of evaluators who evaluated > 0
	numberOfConEvaluators: optional(number()), //count of evaluators who evaluated < 0
	averageEvaluation: optional(number()), //average evaluation
	sumSquaredEvaluations: optional(number()), //sum of squared evaluations
	standardDeviation: optional(number()), //standard deviation of evaluations
	agreementIndex: optional(number()), // 1 - t·SEM*, range [0,1] — confidence-adjusted agreement
	likeMindedness: optional(number()), // 1 - SEM*, range [0,1] — simple opinion similarity (user-facing)
	confidenceIndex: optional(number()), // Gamma formula, range [0,1] — how representative the sample is
	// N as it was resolved when this score was computed — the stakeholder count
	// the finite-population correction divided by. Denormalised deliberately:
	// it is declared on an ancestor, and without it here every surface that
	// shows a corrected score would have to walk the tree to say "50 of 500".
	//
	// It is not an optimisation, it is an accountability record. A smaller N
	// raises the score, so the number has to travel WITH the score it produced
	// rather than being re-derived later from settings that may since have
	// changed. Absent means no bounded population was known and the score is
	// uncorrected.
	stakeholderCount: optional(number()),
	// Questions only. How many distinct people have evaluated anything under
	// THIS question or any question above it — the deliberation's actual
	// electorate, as opposed to everyone who happened to load the page. Every
	// option beneath a question reads its parent's value as N (see
	// resolveStakeholderCount) so the number costs the evaluation trigger no
	// extra read: it is already holding the parent document.
	//
	// Maintained by functions/src/progress/chainVoters.ts. Absent means nobody
	// has voted in this question's chain yet, which is honestly no electorate
	// at all rather than an electorate of zero.
	chainEvaluators: optional(number()),
	viewed: optional(number()), //number of users who viewed the evaluation
	evaluationRandomNumber: optional(number()),
	selectionFunction: optional(enum_(SelectionFunction)), // it is used for selecting in mass consensus random, voting and top suggestions
});

export type StatementEvaluation = InferOutput<typeof StatementEvaluationSchema>;

export enum EvaluationUI {
	suggestions = 'suggestions',
	voting = 'voting',
	checkbox = 'checkbox',
	clustering = 'clustering',
}

export const StatementEvaluationSettingsSchema = object({
	maxVotesPerUser: optional(number()),
	evaluationUI: enum_(EvaluationUI),
	// N: the number of STAKEHOLDERS — everyone with standing in this decision,
	// whether or not the process reached them. A settlement of 500 residents
	// has 500 stakeholders even if only 320 were invited. Declared once on a
	// group or question and inherited by everything beneath it (see
	// resolveStakeholderCount). Drives the finite-population correction on C_p
	// as well as the confidence index; leaving it unset means "no bounded
	// population" and yields the uncorrected formula.
	targetPopulation: optional(number()),
	samplingQuality: optional(number()), // q: sampling quality (0-1], default 0.3
	anchored: optional(
		object({
			//a two-phase process where users propose options, and evaluations always include admin-selected anchored options alongside randomly chosen user options
			anchored: optional(boolean()), //if true, some statements are anchored to be represented in the evaluation.
			numberOfAnchoredStatements: optional(number()), //the number of anchored statements in the evaluation (while the others are not anchored)
			differentiateBetweenAnchoredAndNot: optional(boolean()), //if true, the evaluation will differentiate between anchored and not anchored statements
			anchorIcon: optional(string()),
			anchorDescription: optional(string()),
			anchorLabel: optional(string()),
		}),
	), //the admin can chose to anchor some of the statements to be evaluated
});

export type StatementEvaluationSettings = InferOutput<typeof StatementEvaluationSettingsSchema>;

export const UserEvaluationSchema = object({
	// Composite ID: ${userId}--${parentStatementId}
	userEvaluationId: string(),

	// The user who is evaluating (can be anonymous)
	userId: string(),

	// The parent statement/question being evaluated
	parentStatementId: string(),

	// Array of statement IDs that have been evaluated
	evaluatedOptionsIds: array(string()),

	// Timestamps in milliseconds
	createdAt: number(),
	lastUpdated: number(),

	// Optional optimization fields
	evaluatedCount: optional(number()),
	totalOptionsAvailable: optional(number()),
	completedAt: optional(number()),

	/** Whether this evaluation was collected during test/pilot mode */
	isTestData: optional(boolean()),
	/** Timestamp when this data was retroactively marked as test data (if applicable) */
	markedAsTestAt: optional(number()),
});

export type UserEvaluation = InferOutput<typeof UserEvaluationSchema>;
