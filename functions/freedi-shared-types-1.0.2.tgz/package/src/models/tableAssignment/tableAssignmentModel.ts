import {
	array,
	boolean,
	InferOutput,
	integer,
	maxLength,
	maxValue,
	minLength,
	minValue,
	number,
	object,
	optional,
	picklist,
	pipe,
	regex,
	string,
} from 'valibot';
import { SideValueSchema } from '../classroom/classroomModel';
import { TableAssignmentClosenessSchema } from './tableAssignmentCloseness';

/**
 * Tables (שולחנות): shared table-assignment product. Data model.
 *
 * Contract shared by apps/tables (and any app that opens it) and the
 * Cloud Functions that own writes. Field names are the wire format.
 * All timestamps are milliseconds. Concept names: TableAssignment*, never
 * "allocation" or "rooms".
 *
 * Doc ids: session = `tableAssignmentId`; participant = `${sessionId}_${uid}`.
 */

/** Seats per table when the host sets nothing. */
export const TABLE_ASSIGNMENT_TABLE_SIZE_DEFAULT = 7;
/** Worst allowed table deviation from the crowd, in population-sd units. */
export const TABLE_ASSIGNMENT_BALANCE_TOLERANCE_DEFAULT = 0.3;
/** Ranked preferences a participant may save. */
export const TABLE_ASSIGNMENT_MAX_PREFERENCES = 3;
/** Smallest table a host can choose. */
export const TABLE_ASSIGNMENT_TABLE_SIZE_MIN = 3;
/** Smallest table size a stored session may hold: older sessions were allowed 2. */
export const TABLE_ASSIGNMENT_TABLE_SIZE_STORED_MIN = 2;
/** Largest table a host can choose. */
export const TABLE_ASSIGNMENT_TABLE_SIZE_MAX = 20;
/** Most tables one topic may open. */
export const TABLE_ASSIGNMENT_MAX_TABLES_PER_TOPIC = 50;
/** Longest title, topic label, or position label. */
export const TABLE_ASSIGNMENT_TITLE_MAX_LENGTH = 200;
/** Longest topic description. */
export const TABLE_ASSIGNMENT_DESCRIPTION_MAX_LENGTH = 2000;
/** Longest place of the event (free text). */
export const TABLE_ASSIGNMENT_EVENT_PLACE_MAX_LENGTH = 200;
/** The event date: a calendar day, 'YYYY-MM-DD'. Not a timestamp. */
export const TABLE_ASSIGNMENT_EVENT_DATE_PATTERN = /^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/;
/** The event time: wall-clock 'HH:MM', 24 hours. Not a timestamp. */
export const TABLE_ASSIGNMENT_EVENT_TIME_PATTERN = /^([01]\d|2[0-3]):[0-5]\d$/;
/** Longest participant full name. */
export const TABLE_ASSIGNMENT_FULL_NAME_MAX_LENGTH = 100;
/** The balance tolerance behind each strictness choice. Any other stored number is a custom value. */
export const TABLE_ASSIGNMENT_STRICTNESS = { strict: 0.15, balanced: 0.3, flexible: 0.45 } as const;
/** The five stops a participant answers the position question on. */
export const TABLE_ASSIGNMENT_POSITION_STOPS = [0, 25, 50, 75, 100] as const;

/**
 * How many topics the gathering has (Setup's "כמה נושאים יש במפגש?"). `one`: the
 * server keeps a single topic named after the event and the mode is `ranked`;
 * nobody picks a topic. Stored as a plain string (strict-parse trap): read it
 * through tableAssignmentTopicCountOf.
 */
export const TABLE_ASSIGNMENT_TOPIC_COUNTS = ['one', 'several'] as const;
export type TableAssignmentTopicCount = (typeof TABLE_ASSIGNMENT_TOPIC_COUNTS)[number];
/** Sessions saved before the question existed have several topics. */
export const TABLE_ASSIGNMENT_TOPIC_COUNT_DEFAULT: TableAssignmentTopicCount = 'several';

/** Lifecycle of one TableAssignment: draft, registration open/closed, published, ended. */
export const TableAssignmentStatusSchema = picklist([
	'draft',
	'registrationOpen',
	'registrationClosed',
	'published',
	'ended',
]);
export type TableAssignmentStatus = InferOutput<typeof TableAssignmentStatusSchema>;

/** `direct`: participants pick a table. `ranked`: they rank topics and the engine seats them. */
export const TableAssignmentModeSchema = picklist(['direct', 'ranked']);
export type TableAssignmentMode = InferOutput<typeof TableAssignmentModeSchema>;

const TitleSchema = pipe(string(), minLength(1), maxLength(TABLE_ASSIGNMENT_TITLE_MAX_LENGTH));
const MillisSchema = pipe(number(), integer(), minValue(0));
const NonNegativeIntSchema = pipe(number(), integer(), minValue(0));

/** The optional position question (עמדה): one axis 0..100 with two poles. */
export const TableAssignmentPositionQuestionSchema = object({
	label: TitleSchema,
	poleA: TitleSchema,
	poleB: TitleSchema,
});
export type TableAssignmentPositionQuestion = InferOutput<
	typeof TableAssignmentPositionQuestionSchema
>;

/**
 * When and where the gathering is, as the host wants participants to see it.
 * All three parts are optional and independent. Date and time are wall-clock
 * strings (the event's own local time), never timestamps.
 */
export const TableAssignmentEventSchema = object({
	date: optional(pipe(string(), regex(TABLE_ASSIGNMENT_EVENT_DATE_PATTERN))),
	time: optional(pipe(string(), regex(TABLE_ASSIGNMENT_EVENT_TIME_PATTERN))),
	place: optional(
		pipe(string(), minLength(1), maxLength(TABLE_ASSIGNMENT_EVENT_PLACE_MAX_LENGTH)),
	),
});
export type TableAssignmentEvent = InferOutput<typeof TableAssignmentEventSchema>;

export const TableAssignmentSettingsSchema = object({
	tableSize: optional(
		pipe(
			number(),
			integer(),
			minValue(TABLE_ASSIGNMENT_TABLE_SIZE_STORED_MIN),
			maxValue(TABLE_ASSIGNMENT_TABLE_SIZE_MAX),
		),
		TABLE_ASSIGNMENT_TABLE_SIZE_DEFAULT,
	),
	balanceTolerance: optional(
		pipe(number(), minValue(0)),
		TABLE_ASSIGNMENT_BALANCE_TOLERANCE_DEFAULT,
	),
	positionQuestion: optional(TableAssignmentPositionQuestionSchema),
	/** How many people the host expects; only feeds the setup summary, never the seating. */
	expectedParticipants: optional(pipe(number(), integer(), minValue(1))),
	/** Lets a person take over a registration by typing the same full name. Absent means off. */
	allowReturnByName: optional(boolean()),
	/** 'one' | 'several' (TABLE_ASSIGNMENT_TOPIC_COUNTS), a plain string. Fixed once registration opens. */
	topicCount: optional(string()),
	/** When and where the gathering is; shown to participants once they registered. Absent on older sessions. */
	event: optional(TableAssignmentEventSchema),
});
export type TableAssignmentSettings = InferOutput<typeof TableAssignmentSettingsSchema>;

/** One session. Collection `tableAssignments`, doc id `tableAssignmentId`. */
export const TableAssignmentSchema = object({
	tableAssignmentId: string(),
	hostUid: string(),
	contextStatementId: optional(string()),
	title: TitleSchema,
	mode: TableAssignmentModeSchema,
	status: TableAssignmentStatusSchema,
	settings: TableAssignmentSettingsSchema,
	publishedRunId: optional(string()),
	/**
	 * Direct mode under the bridge rule (IA tables-class-bridge 2.3): a person
	 * chooses a topic, the system makes the tables, and closing registration
	 * also publishes them. Set on every session created since; absent on older
	 * sessions, which finish under the choose-a-table rule (seat counters).
	 */
	splitByTopic: optional(boolean()),
	/** When the answers were erased after the session ended. Absent while they are still stored. */
	answersErasedAt: optional(MillisSchema),
	createdAt: MillisSchema,
	lastUpdate: MillisSchema,
});
export type TableAssignment = InferOutput<typeof TableAssignmentSchema>;

/** A topic (נושא). Collection `tableAssignmentTopics`. */
export const TableAssignmentTopicSchema = object({
	topicId: string(),
	sessionId: string(),
	title: TitleSchema,
	description: optional(pipe(string(), maxLength(TABLE_ASSIGNMENT_DESCRIPTION_MAX_LENGTH))),
	/** Imported topics point at the original proposal Statement. */
	sourceStatementId: optional(string()),
	/** C_p: the proposal's consensus at registration time (describes the proposal, not a person). */
	consensus: optional(number()),
	/** Hard cap on tables opened for this topic. */
	maxTables: optional(
		pipe(number(), integer(), minValue(1), maxValue(TABLE_ASSIGNMENT_MAX_TABLES_PER_TOPIC)),
	),
	order: NonNegativeIntSchema,
	/**
	 * Direct mode under splitByTopic: how many people chose this topic. A count,
	 * no identities; server-written. Absent means nobody yet.
	 */
	chosenCount: optional(NonNegativeIntSchema),
});
export type TableAssignmentTopic = InferOutput<typeof TableAssignmentTopicSchema>;

/** Topic ids, best first, at most three. */
export const TableAssignmentPreferencesSchema = pipe(
	array(string()),
	maxLength(TABLE_ASSIGNMENT_MAX_PREFERENCES),
);

/**
 * A registrant (נרשם/ת). Collection `tableAssignmentParticipants`,
 * doc id `${sessionId}_${uid}` (see tableAssignmentParticipantId).
 * `position` missing means "not specified" (לא צוין), never the middle.
 * Private to its owner: the host reads names from the roster, never this.
 */
export const TableAssignmentParticipantSchema = object({
	sessionId: string(),
	uid: string(),
	fullName: pipe(string(), minLength(1), maxLength(TABLE_ASSIGNMENT_FULL_NAME_MAX_LENGTH)),
	preferences: TableAssignmentPreferencesSchema,
	position: optional(SideValueSchema),
	/** Direct mode: the table the participant joined. */
	chosenTableIndex: optional(NonNegativeIntSchema),
	registeredAt: MillisSchema,
	/** This registration took over another one by full name, so it cannot be cancelled. */
	claimedByName: optional(boolean()),
	/**
	 * The personal link's code (class.wizcol.com/seat/:seatCode), made by
	 * tablesSeatLink. Lives here because only the owner reads this record; the
	 * server keeps a hash of it apart to find the registration again.
	 */
	seatCode: optional(string()),
});
export type TableAssignmentParticipant = InferOutput<typeof TableAssignmentParticipantSchema>;

/**
 * A registrant's name card. Collection `tableAssignmentRoster`, same doc id as
 * the private record. What the host sees: a name and progress, never an answer.
 */
export const TableAssignmentRosterEntrySchema = object({
	sessionId: string(),
	uid: string(),
	fullName: pipe(string(), minLength(1), maxLength(TABLE_ASSIGNMENT_FULL_NAME_MAX_LENGTH)),
	/** See tableAssignmentNameKey. */
	nameKey: string(),
	registeredAt: MillisSchema,
	hasPreferences: boolean(),
	/** Direct mode: the table the participant joined. */
	chosenTableIndex: optional(NonNegativeIntSchema),
	/** Someone took this registration over by typing the same full name. */
	claimedByName: optional(boolean()),
});
export type TableAssignmentRosterEntry = InferOutput<typeof TableAssignmentRosterEntrySchema>;

/** How many registered. Collection `tableAssignmentCounters`, doc id = session id. */
export const TableAssignmentCounterSchema = object({
	sessionId: string(),
	registered: NonNegativeIntSchema,
});
export type TableAssignmentCounter = InferOutput<typeof TableAssignmentCounterSchema>;

/** Two spellings of one full name compare equal: spacing, case and Unicode form are ignored. */
export function tableAssignmentNameKey(fullName: string): string {
	return fullName.normalize('NFKC').trim().replace(/\s+/g, ' ').toLocaleLowerCase();
}

/** The session's topic count; anything but 'one' reads as several. */
export function tableAssignmentTopicCountOf(
	settings: Pick<TableAssignmentSettings, 'topicCount'> | undefined,
): TableAssignmentTopicCount {
	return settings?.topicCount === 'one' ? 'one' : TABLE_ASSIGNMENT_TOPIC_COUNT_DEFAULT;
}

/** Direct mode where people choose a topic and the tables are made at closing (2.3). */
export function isTableAssignmentSplitByTopic(
	session: Pick<TableAssignment, 'mode' | 'splitByTopic'>,
): boolean {
	return session.mode === 'direct' && session.splitByTopic === true;
}

/**
 * The split rule (IA tables-class-bridge 2.1): `people` who chose one topic at
 * tables of at most `tableSize` open ceil(people / tableSize) tables whose sizes
 * differ by at most one, largest first. 70 at 7: ten of 7; 71: five of 7 and six
 * of 6. With tableSize >= 3 no table of one comes out unless people is 1.
 */
export function tableAssignmentTableSizes(people: number, tableSize: number): number[] {
	if (!Number.isInteger(people) || people <= 0) return [];
	const size = Math.max(1, Math.floor(tableSize));
	const tables = Math.ceil(people / size);
	const base = Math.floor(people / tables);
	const extra = people % tables;

	return Array.from({ length: tables }, (_, i) => (i < extra ? base + 1 : base));
}

export function tableAssignmentParticipantId(sessionId: string, uid: string): string {
	return `${sessionId}_${uid}`;
}

export const TableAssignmentRunStatusSchema = picklist([
	'computing',
	'ready',
	'published',
	'superseded',
]);
export type TableAssignmentRunStatus = InferOutput<typeof TableAssignmentRunStatusSchema>;

/** Same shape as the engine's TableStats (packages/table-assignment). */
export const TableAssignmentTableStatsSchema = object({
	n: NonNegativeIntSchema,
	mean: array(number()),
	sd: array(number()),
	deviation: number(),
});
export type TableAssignmentTableStats = InferOutput<typeof TableAssignmentTableStatsSchema>;

export const TableAssignmentRunTableSchema = object({
	index: NonNegativeIntSchema,
	topicId: string(),
	memberUids: array(string()),
	/** Always empty on runs computed now; older documents may still hold figures. */
	stats: TableAssignmentTableStatsSchema,
	/** How close this table is to the room. Host previews only; absent on published and older runs. */
	closeness: optional(TableAssignmentClosenessSchema),
});
export type TableAssignmentRunTable = InferOutput<typeof TableAssignmentRunTableSchema>;

const PopulationStatsSchema = object({
	n: NonNegativeIntSchema,
	mean: array(number()),
	sd: array(number()),
});

const BalanceMetricsSchema = object({
	max: number(),
	mean: number(),
	tolerance: number(),
	withinTolerance: boolean(),
});

const PreferenceMetricsSchema = object({
	/** byRank[0] = participants seated at their first choice, and so on. */
	byRank: array(number()),
	none: number(),
	noPreference: number(),
	score: number(),
	maxScore: number(),
});

/**
 * What a run stores about the room. `population` and `balance.max/mean` are
 * written empty (0 and []) so no figure about positions is ever stored; older
 * documents may still hold figures. `preferences` is empty on a published run.
 */
export const TableAssignmentMetricsSchema = object({
	population: PopulationStatsSchema,
	balance: BalanceMetricsSchema,
	preferences: PreferenceMetricsSchema,
	/** At least three people gave a position. Absent on older runs. */
	hasEnoughPositions: optional(boolean()),
});
export type TableAssignmentMetrics = InferOutput<typeof TableAssignmentMetricsSchema>;

/** One computed seating. Collection `tableAssignmentRuns`. */
export const TableAssignmentRunSchema = object({
	runId: string(),
	sessionId: string(),
	/** Only on older documents: with the engine, a seed lets a reader replay the seating and solve for the answers. */
	seed: optional(number()),
	status: TableAssignmentRunStatusSchema,
	tables: array(TableAssignmentRunTableSchema),
	metrics: TableAssignmentMetricsSchema,
	/** Hash of the frozen input; a published run is only valid while it still matches. */
	inputHash: string(),
	createdAt: MillisSchema,
	publishedAt: optional(MillisSchema),
});
export type TableAssignmentRun = InferOutput<typeof TableAssignmentRunSchema>;
