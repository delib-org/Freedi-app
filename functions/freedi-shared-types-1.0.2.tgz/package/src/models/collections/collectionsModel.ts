export enum Collections {
    statements = 'statements',
    statementDeletions = 'statementDeletions', // tombstones for deleted statements (delta-listener delete sync)
    statementEmbeddings = 'statementEmbeddings', // server-only vectors per statement, kept off the statement doc so listeners don't download them
    statementSnapShots = 'statementSnapshots',
    statementHistory = 'statementHistory', // subcollection on statements/{id}/statementHistory
    termsOfUseAcceptance = 'termsOfUseAcceptance',
    statementsSettings = 'statementsSettings',
    statementsMetaData = 'statementsMeta',
    statementsPasswords = 'statementsPasswords',
    statementsSubscribe = 'statementsSubscribe',
    massConsensus = 'massConsensus',
    massConsensusMembers = 'massConsensusMembers',
    massConsensusProcesses = 'massConsensusProcesses',
    choseBy = 'choseBy',
    participants = 'participants',
    rooms = 'rooms',
    roomParticipants = 'roomParticipants',
    roomsSettings = 'roomsSettings',
    evaluations = 'evaluations',
    votes = 'votes',
    users = 'usersV2',
    usersData = 'usersData',
    userDemographicQuestions = 'userDemographicQuestions',
    usersSettings = 'usersSettings',
    resultsTriggers = 'resultsTriggers',
    results = 'results',
    maps = 'maps',
    agreements = 'agreements',
    timers = 'timers-settings',
    timersRooms = 'timers-rooms',
    invitations = 'invitations',
    evaluators = 'evaluators',
    documents = 'documents',
    importance = 'importance',
    approval = 'approval',
    awaitingUsers = 'awaitingUsers',
    agrees = 'agrees',
    documentsSigns = 'documentsSigns',
    signatures = 'signatures',
    stages = 'stages',
    steps = 'steps',
    signUsers = 'signUsers',
    statementViews = 'statementViews',
    statementSegments = 'statementSegments',
    inAppNotifications = 'inAppNotifications',
    pushNotifications = 'pushNotifications',
    emailNotifications = 'emailNotifications',
    notificationSettings = 'notificationSettings',
    askedToBeNotified = 'askedToBeNotified',
    polarizationIndex = 'polarizationIndex',
    userDemographicEvaluations = 'userDemographicEvaluations',
    online = 'online',
    questionnaires = 'questionnaires',
    questionnaireQuestions = 'questionnaireQuestions',
    fairDivision = 'fairDivision',
    feedback = 'feedback',
    refinementSessions = 'refinementSessions',
    evidencePosts = 'evidencePosts',
    evidenceVotes = 'evidenceVotes',
    userEvaluations = 'userEvaluations',
    commentVerdicts = 'commentVerdicts',
    helperPoints = 'helperPoints',
    surveys = 'surveys',
    surveyProgress = 'surveyProgress',
    surveyAdmins = 'surveyAdmins',
    surveyAdminInvitations = 'surveyAdminInvitations',
    adminInvitations = 'adminInvitations',
    viewerLinks = 'viewerLinks',
    documentCollaborators = 'documentCollaborators',
    joinDelegateInvitations = 'joinDelegateInvitations',
    joinDelegates = 'joinDelegates',
    clusterEvaluationLinks = 'clusterEvaluationLinks',
    suggestions = 'suggestions',
    documentVersions = 'documentVersions',
    versionChanges = 'versionChanges',
    versioningSettings = 'versioningSettings',
    paragraphReplacementQueue = 'paragraphReplacementQueue',
    versionControlAudit = 'versionControlAudit',
    coherenceRecords = 'coherenceRecords',
    documentActionHistory = 'documentActionHistory',
    documentReports = 'documentReports',

    // Admin analytics
    adminStats = 'adminStats',

    // Content moderation
    moderationLogs = 'moderationLogs',

    // Engagement system
    notificationQueue = 'notificationQueue',
    creditLedger = 'creditLedger',
    userEngagement = 'userEngagement',
    engagementEvents = 'engagementEvents',
    creditRules = 'creditRules',

    // Research logging
    researchLogs = 'researchLogs',
    researchConsent = 'researchConsent',

    // Topic-cluster pipeline caches
    clusteringTaxonomies = 'clusteringTaxonomies',
    clusteringNormalizations = 'clusteringNormalizations',

    // Agora classroom deliberative game
    agoraTopicPackages = 'agoraTopicPackages',
    agoraSessions = 'agoraSessions',
    agoraParticipants = 'agoraParticipants',
    agoraScores = 'agoraScores',
    agoraValueAnswers = 'agoraValueAnswers',
    agoraCharacterReviews = 'agoraCharacterReviews',
    agoraSchools = 'agoraSchools',
    agoraClasses = 'agoraClasses',
    agoraClassMembers = 'agoraClassMembers',
    agoraStudentAggregates = 'agoraStudentAggregates',
    agoraClassAggregates = 'agoraClassAggregates',
    agoraStats = 'agoraStats',
    agoraTeacherAggregates = 'agoraTeacherAggregates',
    agoraTeacherUsage = 'agoraTeacherUsage',
    agoraIdentities = 'agoraIdentities',
    agoraTeacherMessages = 'agoraTeacherMessages',
    agoraTeacherPrompts = 'agoraTeacherPrompts',

    // Israeli Odyssey pre-election civic-voice game
    odysseyGames = 'odysseyGames',
    odysseyJourneys = 'odysseyJourneys',
    // Letters to the developers, and the throttle counters that guard them.
    // Both are written only by odysseyFeedbackSubmit — server-only, see
    // firestore.rules. The feedback docs hold reply-to addresses players
    // volunteered, so no client may read them.
    odysseyFeedback = 'odysseyFeedback',
    odysseyRateLimits = 'odysseyRateLimits',

    // WizCol Studio — consultant organizations (Cloud-Function-only writes)
    organizations = 'organizations',
    organizationMembers = 'organizationMembers',
    organizationInvitations = 'organizationInvitations',
    organizationActivities = 'organizationActivities',

    // Per-question participation funnel (server-maintained counters + markers)
    questionProgress = 'questionProgress',
    questionParticipation = 'questionParticipation',

    // WizCol Studio — "Start a question with AI" (Cloud-Function-only writes)
    studioPlanSessions = 'studioPlanSessions',
    scheduledActions = 'scheduledActions',
    studioRateLimits = 'studioRateLimits',

    odysseyDigestState = 'odysseyDigestState',
}
