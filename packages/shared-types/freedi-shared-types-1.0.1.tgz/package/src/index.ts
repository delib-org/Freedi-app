// Base types and utilities
export {
  StatementType,
  DeliberativeElement,
  QuestionStage,
  Access,
  membersAllowed,
  QuestionType,
  QuestionStagesType,
  DocumentType,
  DeliberationType,
  StepType,
  Screen,
  SortType,
  QuestionStep
} from "./models/TypeEnums";
export { isMember, maxKeyInObject, getRandomUID } from "./models/TypeUtils";
export { functionConfig } from "./models/ConfigFunctions";

// Agreement models
export type {
  Agreement,
  AgreeDisagree,
  Agree,
  Importance,
  DocumentApproval,
  DocumentImportance
} from "./models/agreement/Agreement";

export {
  AgreementSchema,
  AgreeDisagreeSchema,
  AgreeSchema,
  ImportanceSchema,
  DocumentApprovalSchema,
  DocumentImportanceSchema,
  AgreeDisagreeEnum
} from "./models/agreement/Agreement";

// Approval models
export type { Approval } from "./models/approval/Approval";
export { ApprovalSchema } from "./models/approval/Approval";

// Suggestion models
export type { Suggestion, TypingStatus } from "./models/suggestion/suggestionModel";
export { SuggestionSchema, TypingStatusSchema } from "./models/suggestion/suggestionModel";

// ChoseBy models
export type {
  ChoseBy
} from "./models/choseBy/ChoseByTypes";

export {
  ChoseBySchema,
  CutoffType,
  ChoseByEvaluationType,
  defaultChoseBySettings
} from "./models/choseBy/ChoseByTypes";

// Document models
export type {
  DocumentSigns,
  Signature
} from "./models/document/index";

export {
  DocumentSignsSchema,
  SignatureSchema,
  SignatureType
} from "./models/document/index";

// Evaluation models
export type {
  Evaluation,
  Evaluator,
  StatementEvaluation,
  StatementEvaluationSettings,
  UserEvaluation,
  UserEvaluationSchema
} from "./models/evaluation/Evaluation";

export {
  EvaluationSchema,
  EvaluatorSchema,
  StatementEvaluationSchema,
  StatementEvaluationSettingsSchema,
  SelectionFunction,
  EvaluationUI
} from "./models/evaluation/Evaluation";

// Invitation models
export type { Invitation } from "./models/invitation/Invitation";
export { InvitationSchema } from "./models/invitation/Invitation";

// Admin Invitation models
export type {
  AdminInvitation,
  ViewerLink,
  DocumentCollaborator
} from "./models/adminInvitation/AdminInvitation";

export {
  AdminInvitationSchema,
  ViewerLinkSchema,
  DocumentCollaboratorSchema,
  AdminPermissionLevel,
  AdminInvitationStatus,
  hasPermissionLevel,
  INVITATION_EXPIRY
} from "./models/adminInvitation/AdminInvitation";

// MassConsensus models
export type {
  MassConsensusMember,
  MassConsensusProcess,
  MassConsensusStage,
  ExplanationConfig,
  PostActionConfig,
  ExplanationDisplayMode
} from "./models/massConsensus/massConsensusModel";

export {
  MassConsensusPageUrls,
  MassConsensusPageUrlsSchema,
  MassConsensusMemberSchema,
  MassConsensusProcessSchema,
  MassConsensusStageSchema,
  MassConsensusStageType,
  MassConsensusStageTypeSchema,
  ExplanationConfigSchema,
  PostActionConfigSchema,
  ExplanationDisplayModeSchema,
  defaultStageTemplates
} from "./models/massConsensus/massConsensusModel";

// Notification models
export type { NotificationType, ReadContext, NotificationReadStatusType } from "./models/notification/Notification";
export { NotificationSchema, NotificationReadStatusSchema } from "./models/notification/Notification";

// Question models
export type { QuestionSettings } from "./models/question/QuestionType";
export { QuestionSettingsSchema } from "./models/question/QuestionType";

// Results models
export type { Results, ResultsSettings } from "./models/results/Results";
export { ResultsBy, CutoffBy, ResultsSettingsSchema, defaultResultsSettings } from "./models/results/Results";

// Stage models
export { StageSelectionType } from "./models/stage/stageTypes";

// Paragraph models
export type {
  Paragraph
} from "./models/paragraph/paragraphModel";

export {
  ParagraphSchema,
  ParagraphType
} from "./models/paragraph/paragraphModel";

// Statement models
export type {
  SimpleStatement
} from "./models/statement/SimpleStatement";

export {
  SimpleStatementSchema,
} from "./models/statement/SimpleStatement";
export {
  statementToSimpleStatement
} from "./models/statement/statementToSimple";
export type {
  StatementSettings
} from "./models/statement/StatementSettings";

export {
  StatementSettingsSchema,
  evaluationType
} from "./models/statement/StatementSettings";
export type {
  StatementSubscription,
  StatementView,
  WaitingMember
} from "./models/statement/StatementSubscription";

export {
  StatementSubscriptionSchema,
  getStatementSubscriptionId,
  StatementViewSchema,
  WaitingMemberSchema
} from "./models/statement/StatementSubscription";
export type {
  Statement,
  LastMessage,
  StatementMetaData
} from "./models/statement/StatementTypes";

export {
  LastMessageSchema,
  StatementSchema,
  StatementMetaDataSchema
} from "./models/statement/StatementTypes";
export {
  createBasicStatement,
  createStatementObject,
  createParagraphStatement,
  createSuggestionStatement,
  defaultStatementSettings
} from "./models/statement/StatementUtils";
export type { CreateStatementParams } from "./models/statement/StatementUtils";

// User models
export type {
  User,
  Membership,
  Step,
  Creator
} from "./models/user/User";

export {
  UserSchema,
  MembershipSchema,
  StepSchema,
  CreatorSchema,
  LoginType
} from "./models/user/User";
export type {
  UserSettings,
  UserData
} from "./models/user/UserSettings";

export {
  Role,
  Languages,
  userSettingsSchema,
  UserDataSchema
} from "./models/user/UserSettings";

export {
  createSubscription,
  updateArray
} from "./controllers/helpers";

// Vote models
export type { Vote, VotingSettings } from "./models/vote/votingModel";
export { VoteSchema, getVoteId, VotingSettingsSchema } from "./models/vote/votingModel";

export type { StatementSnapShot } from "./models/statement/StatementSnapShot";
export { statementSnapShotSchema } from "./models/statement/StatementSnapShot";

export type { UserDemographicQuestion, DemographicOption, DemographicQuestionScope, ExcludedInheritedDemographics } from "./models/userDemographic/userDemographicModel";
export {
  UserDemographicQuestionType, UserDemographicQuestionSchema,
  DemographicOptionSchema, DemographicQuestionScopeSchema, ExcludedInheritedDemographicsSchema } from "./models/userDemographic/userDemographicModel";

export { Collections } from "./models/collections/collectionsModel";

export type {
  PolarizationIndex,
  AxesItem,
  DemographicGroup
} from "./models/polarizationIndex/polarizationIndexModel";

export {
  PolarizationIndexSchema,
  AxesItemSchema,
  DemographicGroupSchema
} from "./models/polarizationIndex/polarizationIndexModel";

export type {
  Online
} from "./models/statement/online";

export {
  OnlineSchema
} from "./models/statement/online";


export type {
  Questionnaire,
  QuestionnaireQuestion
} from "./models/questionnaire/questionnaireModel";

export {
  QuestionnaireSchema,
  QuestionnaireQuestionSchema
} from "./models/questionnaire/questionnaireModel";

export type {
  FairDivisionSelection,
  FairDivisionUserSelection
} from "./models/statement/fairDivision";

export {
  FairDivisionSelectionSchema,
  FairDivisionUserSelectionSchema
} from "./models/statement/fairDivision";

export type { Feedback } from "./models/feedback/feedbackModel";
export { FeedbackSchema } from "./models/feedback/feedbackModel";


export { RoomSchema, RoomSettingsSchema, RoomParticipantSchema, DemographicTagSchema } from "./models/rooms/roomsModel";
export type { Room, RoomSettings, RoomParticipant, DemographicTag } from "./models/rooms/roomsModel";

// Survey models
export type {
  Survey,
  SurveySettings,
  SurveyProgress,
  SurveyLogo,
  QuestionOverrideSettings,
  SurveyDemographicPage,
  SurveyDemographicQuestion,
  SurveyDemographicAnswer,
  SurveyExplanationPage,
} from "./models/survey/surveyModel";
export {
  SurveySchema,
  SurveySettingsSchema,
  SurveyProgressSchema,
  SurveyLogoSchema,
  SurveyStatus,
  SurveyStatusSchema,
  SuggestionMode,
  SuggestionModeSchema,
  DisplayMode,
  DisplayModeSchema,
  DEFAULT_SURVEY_SETTINGS,
  QuestionOverrideSettingsSchema,
  DEFAULT_QUESTION_OVERRIDE_SETTINGS,
  SurveyDemographicPageSchema,
  SurveyDemographicQuestionSchema,
  SurveyDemographicAnswerSchema,
  SurveyExplanationPageSchema,
} from "./models/survey/surveyModel";

// MAD Calculation utilities
export type { MadResult } from "./utils/madCalculation";
export {
  calcMadAndMean,
  calculateDCI,
  meetsKAnonymity,
  interpretDivergence,
  interpretDCI,
  DEMOGRAPHIC_CONSTANTS,
} from "./utils/madCalculation";

// Consensus Calculation utilities
export {
  FLOOR_STD_DEV,
  calcStandardError,
  calcAgreement,
  calcBinaryConsensus,
  DEFAULT_REMOVAL_THRESHOLD,
  DEFAULT_ADDITION_THRESHOLD,
  DEFAULT_MIN_EVALUATORS,
  meetsRemovalThreshold,
  meetsAdditionThreshold,
} from "./utils/consensusCalculation";

// Framing models
export type {
  Framing,
  ClusterAggregatedEvaluation,
  FramingRequest,
  ClusterSnapshot,
  FramingSnapshot,
  FramingCreatorType,
  FramingRequestStatus,
} from "./models/framing/framingModel";

export {
  FramingSchema,
  ClusterAggregatedEvaluationSchema,
  FramingRequestSchema,
  ClusterSnapshotSchema,
  FramingSnapshotSchema,
  FramingCreatorTypeSchema,
  FramingRequestStatusSchema,
  CLUSTER_AGGREGATION_CACHE,
  getClusterAggregationId,
  isClusterAggregationValid,
} from "./models/framing/framingModel";

// Embedding models
export type {
  StatementEmbedding,
  SimilarityResult,
  EmbeddingBatchRequest,
  EmbeddingBatchResult,
  EmbeddingStatusReport,
  FindSimilarResponse,
  EmbeddingStatus,
} from "./models/embedding/embeddingModel";

export {
  StatementEmbeddingSchema,
  SimilarityResultSchema,
  EmbeddingBatchRequestSchema,
  EmbeddingBatchResultSchema,
  EmbeddingStatusReportSchema,
  FindSimilarResponseSchema,
  EmbeddingStatusSchema,
  SimilaritySearchMethodSchema,
  SimilaritySearchMethod,
  EMBEDDING_CONFIG,
  hasValidEmbedding,
  validateEmbeddingDimensions,
} from "./models/embedding/embeddingModel";

// Version models
export type {
  DocumentVersion,
  VersionChange,
  ChangeSource,
  VersionGenerationSettings,
  DocumentVersioningSettings,
} from "./models/version/versionModel";

export {
  DocumentVersionSchema,
  VersionChangeSchema,
  ChangeSourceSchema,
  VersionGenerationSettingsSchema,
  DocumentVersioningSettingsSchema,
  VersionStatus,
  ChangeDecision,
  ChangeType,
  ChangeSourceType,
  DEFAULT_VERSION_GENERATION_SETTINGS,
  DEFAULT_VERSIONING_SETTINGS,
  getVersionId,
  getChangeId,
  calculateImpact,
  hasSignificantImpact,
  sortChangesByImpact,
  filterSignificantChanges,
} from "./models/version/versionModel";

// Evidence models
export { EvidenceType } from "./models/evidence/evidenceModel";

// Popper Hebbian models
export type { PopperHebbianScore } from "./models/popper/popperTypes";
export { PopperHebbianScoreSchema } from "./models/popper/popperTypes";

// Replacement Queue models (paragraph version control MVP)
export type {
  PendingReplacement,
  VersionControlAudit,
  VersionArchive,
  DocumentActionHistory,
} from "./models/version/replacementQueueModel";

export {
  PendingReplacementSchema,
  VersionControlAuditSchema,
  VersionArchiveSchema,
  DocumentActionHistorySchema,
  ReplacementQueueStatus,
  AuditAction,
  DocumentActionType,
} from "./models/version/replacementQueueModel";

// Coherence models (document coherence engine)
export type {
  IncoherenceRecord,
  ParagraphReasoningPath,
  FeedbackAddressed,
  CoherenceAnalysisResult,
} from "./models/version/coherenceModel";

export {
  IncoherenceRecordSchema,
  ParagraphReasoningPathSchema,
  FeedbackAddressedSchema,
  IncoherenceType,
  IncoherenceSeverity,
  ParagraphAction,
  getCoherenceRecordId,
} from "./models/version/coherenceModel";